# Journey Into babylon

## Project Genesis

Babylon did not begin as Babylon. On Dec 5, 2025 (#1202) the repository was a generic RPG scaffold called "PercyGame" — a contradiction engine, some SQLAlchemy models, a ChromaDB config, and twenty tests. Two days later it acquired the name it still carries: on Dec 7 (#1559–1573) the project was renamed "Babylon - The Fall of America," and within the same 48 hours it acquired the architectural commitment that governs it to this day.

That commitment arrived through an unusually fast reversal. Phase 2 design first landed as ADR010, "Direct Entities + Formulas" (#2021–2027) — economies and polities as first-class classes. The design was declared insufficient and torn up within hours (#2028), replaced at roughly 7:12am on Dec 7 by ADR011, "Pure Graph Architecture" (#2033–2037): delete the Economy and Politics classes entirely, model everything as nodes and edges, let structure emerge from relations. The mantra minted that morning — **Graph + Math = History** — is still the first line of the repository's operating guidance eight months later. It is hard to overstate how much of the project's subsequent character was fixed in that one decision. Every later fight about class position, sovereignty, doctrine, or electoral form was ultimately a fight about what belongs on a node, what belongs on an edge, and what must be derived rather than declared.

The founding technical decisions clustered tightly around it. The data layer pivoted from XML to JSON with schemas modeled on schema.org (#1388–1538). Dependency injection replaced module-level globals through a ServiceContainer, EventBus, FormulaRegistry, and DatabaseConnection (#2884–2932) — a pattern that survived every subsequent re-layering. A "Memory" RAG pipeline ingested seven canonical Marxist texts into ChromaDB, and immediately became the project's first real slog: the marxists.org archive turned out to be Git-LFS pointers rather than content (#3554–3572), the files were organized by date rather than title (#3928–3943), and once ingestion finally succeeded (#3957) queries returned nothing at all because of a 384-vs-768 embedding-dimension mismatch (#4210, #4266) compounded by an asyncio deadlock in `EmbeddingManager` (#4221). The fix was to abandon async wrappers entirely for direct synchronous Ollama calls (#4311–4316) — the project's first lesson that a clever abstraction that hides a deadlock is worse than a dumb call that works.

The founding *vision*, though, revealed itself in a bug that turned out not to be one. On Dec 9 the vertical-slice CLI appeared to hang after tick 2; event logs simply froze (#4332–4353). Investigation showed this was correct behavior: worker consciousness saturated at 1.0 by tick 2, eliminating Imperial Rent extraction entirely (#4412–4421). The simulation was not broken, it was *incomplete* — it lacked a labor aristocracy. That discovery (#4420–4426) motivated the Imperial Circuit model and established the project's defining reflex: when the simulation misbehaves, first ask whether the theory is missing a term. That reflex recurs, almost verbatim, in Jul 2026 when a statewide economy dies and the fix turns out to be a class-character correction rather than a numeric patch.

By Dec 25 the test suite had grown from 20 to 2,253 tests, Sphinx documentation had ballooned to 2,016 warnings and then been root-caused to a single config flag (#6537), and a NiceGUI dashboard called the "Synopticon" existed — after three separate rounds of CSS layout debugging that each fixed one symptom of the same flex/grid propagation model (#7408–7437, #12874–12976, #12977–12989).

```mermaid
timeline
    title Eras of Babylon
    section Foundations
        Dec 2025 — Genesis : PercyGame renamed Babylon : ADR011 Pure Graph Architecture : RAG corpus ingestion saga : Synopticon dashboard
        Dec 2025-Jan 2026 — Data Foundation : Epoch plus Slice roadmap : Direct-to-3NF loader rebuild : Branch divergence crisis : MarxianHydrator and ValueTensor4x3
    section The Economic Core
        Feb-May 2026 — Speckit Era : ~40 numbered feature specs : Rent Trinity and MELT : Dimensional-mismatch crisis : Constitution 1.0 to 1.8
        May-Jul 2026 — Property Tests and Refactors : Hypothesis invariants : Lawverian dialectics ADR051 : NetworkX to rustworkx ADR052 : Program 09 four-lane sprint
    section Reckoning
        Jul 8-10 2026 — The Loud Machine : Six P0s in one day : Cloudflare token scrub : The Cockpit rebuild : CI resurrected after two months dark
        Jul 11-15 2026 — Gauntlet, Living Map, Living Engine : Two-tier CI/CD : UI found decorative : Seam Observatory and sentinels : 300s tick and event-silence sagas
    section Industrialization
        Jul 16-21 2026 — Programs at Scale : Test estate and Data Constitution : Market Scissors promotion ceremony : Volume III money-scissors : Five-lane parallel build
        Jul 22-27 2026 — Playable Archive : Adversary train and Sparrow : Program 24 TUI goes live : Program 25 political superstructure : Amendment AD Agentic Engineering
```

## Architectural Evolution

The architecture moved in three long waves, each triggered by a different kind of failure.

The **first wave (Dec 2025 – Feb 2026)** was persistence churn. Having chosen a graph substrate, the project could not decide where the graph should live. ADR029 proposed a hybrid NetworkX-plus-KuzuDB split (#14244–14247), then superseded it with a GraphProtocol abstraction layer (#14693–14710) — three persistence decisions in two weeks. The same indecision hit the relational side: a DuckDB migration merged in January (#19711–19724), then a dual SQLite-ETL/DuckDB-runtime split (#20911–20924), then a DuckDB→SQLite seeding tool that partially reversed it (#21008–21023), before settling pragmatically on SQLite as the authoritative reference artifact. By Feb 25 the three-layer shape had crystallized (#31646): PostgreSQL for game runtime, SQLite for reference data, an in-memory graph for topology. That is the "Embedded Trinity" still in the CLAUDE.md, with only the graph library and the vector store later swapped out.

The **second wave (Feb – Jul 2026)** was methodological. The project adopted GitHub Speckit as its default workflow and ran roughly forty numbered feature specs through `specify → clarify → plan → tasks → analyze → implement`, often start-to-merge inside a day. This produced the economic core: ValueTensor4x3, the Rent Trinity (#21906-9, implemented and tagged in under an hour on Jan 30), MELT, Imperial Rent, Gamma visibility, capital stock and class dynamics, crisis mechanics, and eventually the "Capital Volumes I–III" integration. It also produced the project's first genuinely mature architectural instinct: the Director's Jan 30 ruling that the `Simulation` class must be *replaced*, not wrapped (#22221), rejecting the adapter pattern as pre-emptive tech debt — followed a day later by the opposite call, reinstating `ProtocolObserverAdapter` after thread-safety analysis proved it structurally necessary (#23315-36). Taste asserting itself in both directions, with reasons.

Two structural pivots in this wave had long tails. Class position moved from wage thresholds to a five-tier wealth-percentile model with a precarity axis (#25185–25301, Feb 2) — a change that would be re-litigated in July when Program 19 argued classes should not be *assigned* at all. And the data layer was extracted to a standalone `babylon-data` repository (#33757, Mar 1), a separation that later cost weeks when loaders were deleted in refactors and nobody noticed until the Jul 16 Data Constitution Census found 30+ modules gone with orphaned tables and no reload path (#71111–71169).

The **third wave (Jul 2026)** was structural consolidation under pressure, and it is where the architecture actually hardened. Jul 2–3 saw two foundational rewrites land back to back: the Lawverian dialectics category-theory refactor (ADR051, #40163) and the NetworkX→rustworkx substrate migration (Amendment L / ADR052, #40602, #40894-40897). Jul 10 opened Program 14 "Correspondence," a repo-wide re-layering into kernel / models / formulas / topology / domain / persistence / engine with `import-linter` contracts — proposed, then *independently verified against the real import graph* before execution, confirming genuine economics↔engine and persistence↔engine cycles (#49425), and landing five green contracts the same night (#49902, #49913).

From there the pattern repeats at increasing scale. Jul 17 promoted the price/value opposition from shadow to canonical with an explicit "promotion ceremony" — baseline regeneration plus governance doc plus CLAUDE.md update (#72873, ADR078). Jul 19 ratified Amendment U (#90734–90751) after discovering that the spatial hierarchy hex→county→state→nation is not a chain at all but a lattice of parallel county-aggregations, with commuting zones and metro areas as siblings rather than rungs. Jul 20 inverted the reference-database authority entirely: SQLite stopped being the source of truth and became a deterministic *build product* of per-table parquet sources (ADR098, PR #227 at #99097). Jul 21 pivoted the whole toolchain to environment sovereignty, vendoring the Nix devshells into Babylon's own flake and unmounting the infra submodule (ADR102 / Amendment Z, #104874, #104868), and ratified ADR109's Wiring Doctrine (#106948, #106962) — the rule that connecting any dormant construct is a *typed motion* with a required sentinel row, never a bare import-and-call.

The final architectural act in the record is not code at all. On Jul 27 Amendment AD (#123212) and ADR151 (#123232) retired the "Benevolent Dictator" governance model in favor of "Agentic Engineering": Persephone Raskova as Director holding sole ideological authority and merge authority to `main`, with agents as a gate-licensed engineering workforce whose autonomy is bounded by green and red gates rather than case-by-case sign-off. The sweep touched nine files across two commits, and a second wave was needed to catch stale references the first pass missed in CI and tooling YAML (#123306, #123320).

## Key Breakthroughs

The breakthroughs cluster into three kinds: theory correcting code, tests certifying nothing, and wiring that never existed.

**Theory correcting code.** The Dec 9 stall diagnosis (#4420–4426) set the template. It repeated most sharply on Jul 2, 2026, when a 520-tick Michigan-Canada canonical run produced a world that looked alive and was frozen. A controlled A/B experiment first blamed the newer economics (#39803), then *reversed its own verdict* (#39808) after finding the bridge never seeded TENANCY edges, so `ProductionSystem` skipped every worker (#39811–39826). Fixing that restored the workers and killed the bourgeoisie — a second, deeper bug: US counties were being hydrated as `PERIPHERY_PROLETARIAT` instead of `LABOR_ARISTOCRACY`, breaking the Amin/Wallerstein three-class circuit entirely (#39851–39867). Both fixes were grounded in theory, not tuned numerically. The same instinct produced the Feb 6 "Calibration Epistemology" section (#26405–26412): rather than paper over a genuine dimensional mismatch between labor-hour and dollar-denominated profit rates (#26352-56), the team wrote the tension into the docs and chose the flow-based rate deliberately. And on May 16 (#37659) a rate-of-profit test band was widened from [0.05, 0.50] to Marx-empirical [0.05, 2.0] because the *tolerance* was theoretically wrong, not the code.

**Tests certifying nothing.** The single most important recurring discovery in the corpus is that green tests routinely covered dead code. On Jul 19 (#89885–89925), U9's endogenous interest rate reported success and its SC-001 tests passed — while `economy_wide_profit_rate` read `tick_profit_rate` *before* it was stamped on the graph, producing a silently zero interest rate the entire time. A "correct-but-inert" review caught it; the live fix moved Wayne County from `interest_payments=0.0` to `1.18e9`, about 33% of surplus, the first time the `s = p + i + r + t` surplus identity evaluated non-vacuously (#90072–90093). A second review wave then found two more stale-spy tests that never drove a full tick (#89869–89870). The pattern had a sibling on Jul 18, where the SC-001 identity test was itself tautological — deriving its expected value from the code path under test — and needed three separate defect-injection rounds before anyone trusted it (#80774, #80907–80930).

**Wiring that never existed.** On Jul 12 at roughly 11:40am the project's most consequential honesty moment landed: `imperial_rent` was genuinely computed by `ImperialRentSystem` and *never written* to the `hex_latest` table the frontend read (#56524, #56578). The only place those values had ever been populated was a mock seeding fixture (#56978). Weeks of frontend polish were revealed as decoration over an empty pipe. Loading the missing BEA IMPORT_USE Leontief coefficients (31,688 rows across 15 years, #57184–57198) produced real per-county Φ for the first time; wiring real QCEW employment in place of a hardcoded 100k rebalanced organic composition from a fake ~138 to a real ~20.6 (#57654); and by 6:29pm all four "dark" map lenses were confirmed honest (#57669). This generalized on Jul 21 into the corpus's clearest single aha: `NarrativeDirector._retrieve_context_from_typed_events` was called "the definitive smoking gun" (#105281) — the entire RAG pipeline was fully implemented and silently returned `[]` because `self._rag` was never assigned. That crystallized the finding that **the gated-dormancy pattern is universal** (#105273), which directly shaped the eight-train v1.0.0 master plan and, days later, ADR109's Wiring Doctrine.

Two smaller breakthroughs deserve mention for their character. On Jul 15, forcing SQLite to use the correct index cut a query from 1.3s to 0.77ms — a 1700× speedup (#66133) that took `resolve_tick` from ~300s to 10.3s (#66186). And on Jul 20 the BYTE-NEUTRALITY STOP RULE fired for real (#93851, #93852): a task produced genuine 4-of-5-scenario byte drift, and instead of forcing it through, the agent root-caused the ordering mechanism and *rescoped the task* to save-only observability (#93911). That is the Constitution's loud-failure doctrine working in production against the agent's own deliverable.

## Work Patterns

The rhythm is remarkably consistent across eight months, and it is not the rhythm most projects have.

The base loop is **recon → plan → red → green → review → ceremony → commit**, with the reconnaissance phase disproportionately large. Discovery observations account for 61% of all recorded token spend (6.0B of 10.86B); features, bugfixes and refactors combined are under 3.0B. In the July era this became explicit doctrine: the #42 consciousness subagent read 30+ files before writing a line (Jul 20), the Program 24 Archive sweep read 34 documents against ~100 git probes in one session, and U8's `AllegianceSystem` reconnaissance on Jul 22 read over 100 files, several times correcting its own earlier findings mid-stream (#115249) before any code was written. The corpus itself eventually flags this as excessive — on Jul 23 an observation notes "~300 observations emitted for ~45 distinct findings — dedup and branch-check failures identified" (#122353).

Sprints came in three shapes. **Speckit micro-cycles** (Feb–May) ran a full spec lifecycle in a day with short-lived branches. **Parallel worktree waves** (Jul 8 onward) split work into lanes — the six P0 fixes on Jul 8, the four Living Map waves on Jul 11, six concurrent design-sync lanes on Jul 10 morning. **Contract-forked parallel builds** (Jul 21) were the mature form: a single "T1.0" contract commit reserved dialectics opposition keys, coupling slots, and tick-system partitions *before* five lanes started, specifically so the eventual merge would be mechanical rather than exploratory (ADR103, #105425). That cascade merged 252 files and 36,699 insertions into `dev` by 11:49pm as PR #245 (#107894).

Two anti-patterns are visible and worth naming honestly. The first is the **audit loop**: on Jul 14, beginning around 3:22pm, the Director repeatedly asked the agent to survey outstanding branches, merge into `dev`, and produce a go/no-go report. Across roughly forty session restarts each session produced a fresh audit and none performed the merge, closing with a chain of near-duplicate "merge request not executed" observations. The frustration was eventually logged directly (S4420, S4421), and the Director asked the agent to stop generating summaries (S4424–S4426). The arc resolved not by merging but by redirecting the session into Program 19 at 7:57pm (#61200). The same "review all recent work, honest report" framing recurs dozens of times on Jul 9, Jul 12 and Jul 15 with genuine work happening underneath a stale prompt.

The second is **session-summary inflation**. Jul 19 alone carries ~920 session headers against ~3,100 observations; Jul 20 exceeds 500 headers, many of them "credits refilled — resumed" checkpoints. These are artifacts of long-running parallel subagent workflows being sampled repeatedly, not distinct units of work, and any reading of the record has to discount them.

Against those, the discipline holds in ways that matter. Adversarial review gates appear after nearly every unit in the July era and repeatedly catch real defects rather than rubber-stamping: the Sparrow SURVEIL heuristic inverted relative to its own cited doctrine (#110546), the U11 doctrine-fork design carrying three blocker-level defects before implementation (#119225–119246), the bridge sentinel silently dropping non-`get_`-prefixed serializers (#59308, adversarially confirmed at #59381). And scope discipline is enforced when it costs something: a 5200-tick US verification probe was killed and deferred by explicit ruling rather than chased (#74428, #74430), and a stuck SDD subagent that spent 40+ operations in a pure-reconnaissance loop was recognized as stalled and replaced with direct implementation (#73477–73719).

## Technical Debt

Babylon's relationship with debt is unusually explicit: most of it is *catalogued* rather than silently carried, and a surprising amount gets paid inside the same session it is found.

The largest single debt was created by a bold refactor. Commit `a5f73139` deleted `babylon.economics.reproduction` and other modules while landing an incomplete Leontief calculator, leaving ~103 test failures on `dev` (#35468). Recovering took a dedicated `fix/dev-test-debt` branch that eliminated 363 failures and errors (#35547), plus six ADRs and a phased delivery plan just to re-stabilize before real work could resume. That episode is the clearest cost of the project's speed, and it directly produced the SC-007 byte-equality acceptance gate (#36030) that governed structural refactors thereafter.

The Jul 8–10 "Loud Machine" era was a deliberate debt-payment program. The `src/` simplification sweep (ADR058) deleted 36 orphaned schema files and the `pre_embeddings` package, hoisted a triplicated `_get_persistent_data` helper, gutted `SimulationConfig` from 37 dead coefficient fields down to `rng_seed` alone, and established `defines.yaml` as the single generated source of truth for all coefficients. Two days later the legacy web frontend was deleted outright at −39,818 lines (#49094). Jul 16's Data Constitution amputated 16 reference-DB tables and reclaimed 1.3GB via VACUUM (#71450), following a census that found the data dictionary six months stale and systematically wrong about which tables held data — `fact_trade_monthly` was documented as 0 rows while holding 44,808 with live runtime consumers (#71048).

The most instructive debt, though, is the debt that was *left standing on purpose and labeled*. `tick_summary.repression_count` was deliberately shipped NULL with a declared flip-ceremony note for a full unit before the adversary train made it real. The Census `fact_census_institutional_ownership` table was confirmed entirely degenerate — all zeros across 6,570 rows — and escalated to the owner queue rather than faked (#68877–68896). A Garvey/UNIA salary ratio that could not be independently verified anywhere in the corpus was flagged rather than asserted (#66769–66792). `AppShell`, `MapView` and `TopologyView` remained honest-absence skeletons through the entire Jul 22–23 period rather than being stubbed convincingly.

The recurring tax items are equally honest. Golden snapshot regeneration churn was constant during TUI work — nearly every visible change forced 17–25 goldens to be regenerated, sometimes several times a day. The tutorial arc grew from 9 to 24 steps over one segment, and nearly every growth step required hunting 5–9 stale `len(steps) == N` comments across test files. And a security-shaped debt recurred twice: a Cloudflare API token leaked through a tracked `sessions/` directory and required a `git filter-repo` history scrub (#44397), then in July a `snapshot_report.html` committed by accident carried exposed Cloudflare and BLS keys and was blocked by GitHub secret scanning mid-push (#111446–111509).

The durable countermeasure was adopted on Jul 18 as a standing rule (#78068): **every phase of work must ship a sentinel preventing its discovered error class from recurring.** That rule produced the inert-construct sentinel, the NodeType vocabulary sentinel, the fog-containment suite, the intensive-aggregation sensor, and eventually a 22nd sentinel family for formula registration (#106839–106881). It also worked: on Jul 21 the vocabulary sentinel caught fabricated node attributes (`ooda_profile`, `class_consciousness`) introduced by an 18-branch merge wave (#103613–103634) — drift produced by parallel agents, caught by machinery, not by a human reading diffs.

## Challenges and Debugging Sagas

The hardest problems in Babylon share a signature: the symptom is in one layer, the cause is in another, and the first three hypotheses are wrong.

**The event-silence mystery (Jul 15)** is the purest example. A live e2e test showed zero urgent events reaching the frontend across 20 ticks. The first hypothesis — backend severity misclassification — was ruled out because the frontend re-classifies independently (#66281). The second — the event converter covering only 44 of 79 EventTypes — was a real gap but not this bug. The third — struggle-system agitation thresholds never being crossed — was empirically disproven by a headless 30-tick census showing abundant events (#66431). Four more hypothesis-and-disprove cycles through the persistence layer finally landed on the actual cause at #66553: `WorldState.to_graph()` called `model_dump()` without `mode="json"`, so `_make_serializable` choked on enum and datetime values and silently dropped every event on persist. The investigation explicitly recorded that *zero test coverage existed for that code path* (#66545–66552).

**The 300-second `resolve_tick` regression (Jul 15)** ran the same morning. Instrumented logging showed a POST hanging over five minutes; live stack traces showed 297% CPU with "all threads idle," a red herring (#66082); the trail led to a county-fallback query against `FactQcewAnnual`, a 14.6-million-row table, where SQLAlchemy's SQLite dialect **silently drops `INDEXED BY` hints** (#66138–66144). The fix required restructuring the query and adding per-year caching to two adapters that had none and were re-querying every tick.

**The QCEW migration (May 16–17)** was the hardest operational saga: a single migration script ran live against a 10.4 GB SQLite reference database for over sixty hours across many session resumes, surviving a PC crash and a stuck SQLite rollback that needed kernel-level diagnosis and manual VACUUM recovery (#37524–37697).

**The Pydantic `persistent_data` deep-copy bug (Jul 18)** was the day's hardest and the most quietly devastating: Phase 1's automated dict-to-`TickContext` migration broke roughly 111 unit tests because Pydantic v2 deep-copies the `persistent_data` dict on construction rather than sharing the reference multi-tick test fixtures expected. The fix was a documented pattern — chain `persistent_data` from the previous `TickContext`, not the original variable — applied file by file across nine test files over about ninety minutes, with three confirmation passes before anyone trusted it closed (#75847–76024).

Several sagas are notable for how *stupid* the root cause turned out to be relative to the effort. A long-standing end-turn e2e flake, which had resisted timeout increases and pause-logic rewrites, was a one-character regex bug: the status string `"RESOLVING…"` uses a Unicode ellipsis the anchored regex never matched (#76436). The RED_OGV endgame had three structurally unreachable routes because `seed_sovereigns.json` used CLAIMS-edge territory IDs `"canada"` and `"rest_of_usa"` that never matched scenario Territory keys, so `SOV_EXTERIOR_NULL` swallowed every domestic hex (#74933) — fixed by a `SOV_USA_FED` fallback (#74993, ADR080), and then surfacing *again* a week later as a still-live defect in every web session (#122182). The Energy API silently returning empty data traced to one wrong MSN code, `TETPBUS` instead of `TEPRBUS` (#17476). And a "dead key" complaint about ctrl+i in the terminal client resolved only after tracing Textual's alias table to discover that ctrl+i literally *is* Tab at the protocol level (#116572).

Infrastructure produced its own genre. The dev box froze twice on Jul 12 under parallel sentinel test runs; the cause was OpenBLAS defaulting to 12 threads with no cap, fixed by pinning to 1 with a guard test (#58143–58162) — a determinism win as much as a stability one. A separate chroma-mcp leak reclaimed 32GB at peak and traced to an `ls -dt` mtime-based plugin-cache resolver picking stale directories (#58337–58345). On Jul 20 a SQLite VACUUM failed with "disk or database full" despite free disk, because SQLite's temp files routed to a nearly-full tmpfs `/tmp`; `PRAGMA temp_store_directory` fixed it without breaking byte-identity (#98042). And the Nix `PYTHONPATH` shadowing saga on Jul 21 — 91 Nix-store paths prepended ahead of venv site-packages, first misdiagnosed as a missing package (#103558–103564) — was only architecturally resolved by ADR102, and *still* recurred in every fresh worktree for the rest of the day.

The dead ends are recorded as honestly as the wins. Playwright E2E tests were built in December and then explicitly abandoned for subcutaneous mocked-component testing (#7916). A Program 18 subrepo split of `web/` from `src/babylon` was investigated and formally rejected as net-negative because a single determinism contract spans the whole simulation (#57979–57983). A Django 6 / mypy 2 upgrade was attempted and reverted over stub incompatibility (#52632–52646). And Program 09's four-lane sprint produced a claimed "13/13 specs complete" that two independent adversarial audits found to be process cliffs — the engine was mathematically sound and the shipped game crashed at tick 0 (#41778, #41834–41850). Notably, those same audits *refuted* several of their own claimed bugs by reading code at HEAD (#41629, #41784, #41858), which is the behavior that makes the rest of their findings credible.

## Memory and Continuity

Persistent memory is not incidental to this project's method; it is load-bearing, and the record shows both its payoffs and its failure modes.

The clearest saves are the ones where memory prevented redoing finished work. On Dec 7, session S107 verified claims by direct test execution *before* redoing Sprint 1.5, and discovered it was already fully implemented — documentation was corrected instead (#1751–1762). On Jan 28 a tensor-validation session opened by reviewing prior context to confirm 6M QCEW rows were already loaded, avoiding a redundant multi-hour reload (#21412–21416). On Jul 18, U2.1 and U2.2 were independently re-confirmed as already-landed via workflow-journal replay at least four separate times across session boundaries (S6188–S6209) without being re-implemented.

Memory also shaped decisions rather than just informing them. On Jul 27 the Director's standing "no MVP splits" ruling was pulled from memory (#122927, #122929) and preemptively killed a phased-rollout framing before it could be proposed. On Jul 20 the Wayne County W1 ruling was recalled verbatim mid-investigation (#99257) and correctly prevented a redundant migration. The `PYTHONPATH` worktree-shadow gotcha, institutionalized from earlier sessions, was recognized instantly on Jul 19 at least three separate times (#86192, #87104) rather than re-debugged. And on Jul 15 the Ansible workstation role was built directly from a prior dev-box mount-displacement incident report already in the repo (#63625–63639).

Deliberate continuity artifacts appear throughout. The "Babylon Continuation Kit" — six documents built after the Lawverian/rustworkx dual-refactor day (#39878–39887) — was explicitly designed as an agent-agnostic handoff, and paid off directly when Program 09 handed work to a different agent mid-week. The Program 24 test-port ledger was consulted and extended by dozens of parallel agents across Jul 21 (#104072, #104377, #105033). The empirical-invariants memory document was written on Jul 16 specifically so future sessions would not re-derive WID/BEA/LODES variable-code conventions (#70840).

The failures are equally instructive. On Jan 25 six separate memory searches failed to recover a lost SQL-diagnostics conversation, and file-based context recovery had to compensate (#20549–20564). The Jul 14 audit loop is the starkest case: roughly forty session restarts each re-read recent context and each re-derived the same audit, never recognizing that the standing request had already been satisfied — memory recall at session grain, but no tracking of repeated identical instructions across restarts. And on Jul 27 the investigation caught `state.yaml` itself misreporting PR #250 as "tabled" when it had actually merged (#122904) — stale project memory corrected against ground truth. That correction is the healthy pattern the project eventually converged on: **verify memory against git and code before acting on it**, which is exactly what the Jul 5–7 audits did when they refused to trust another agent's session claims and re-derived ground truth from `git log`, HEAD, and SQLite queries.

## Token Economics & Memory ROI

### Headline figures

| Metric | Value |
|---|---|
| Total `discovery_tokens` recorded | **10,856,011,773** (≈10.86 billion) |
| Total observations | 55,898 |
| Date range | 2025-12-06 → 2026-07-27 |
| Distinct memory sessions | 425 |
| Sessions with context injection available | 424 |
| Compression ratio (discovery cost ÷ read-back cost) | ≈493× |
| Explicit recall events (proxy, lower bound) | 50 |
| Estimated net ROI (savings ÷ read tokens invested) | ≈56.6× |

The ~10.86B figure was sanity-checked rather than assumed: `SUM(discovery_tokens)` over 55,893 rows with non-zero values was cross-referenced against `MAX` (1,045,503) and `AVG` (194,228.47), and 55,893 × 194,228.47 ≈ 1.0855 × 10¹⁰ matches the direct sum to within rounding. It is not a unit error — individual observations top out near 1.0M tokens on large investigation turns.

### Monthly breakdown

| month | observations | discovery_tokens | distinct sessions |
|---|---|---|---|
| 2025-12 | 7,276 | 27,018,412 | 63 |
| 2026-01 | 6,105 | 25,839,258 | 101 |
| 2026-02 | 3,505 | 13,950,738 | 91 |
| 2026-03 | 29 | 80,090 | 29 |
| 2026-05 | 2,835 | 16,687,807 | 60 |
| 2026-07 | 36,148 | 10,772,435,468 | 82 |

No rows exist for April or June 2026. July 2026 alone accounts for **99.2%** of all recorded discovery tokens and 65% of all observations, in just 82 sessions — the steepest ramp in the project's history, and consistent with the shift to heavy workflow-subagent fan-out visible in the narrative from Jul 8 onward.

### Type breakdown

| type | n | discovery_tokens |
|---|---|---|
| discovery | 34,059 | 6,007,240,847 |
| feature | 5,412 | 1,717,831,792 |
| change | 9,658 | 1,617,316,758 |
| bugfix | 3,176 | 781,865,293 |
| refactor | 1,646 | 505,295,543 |
| decision | 1,890 | 210,996,544 |
| security_alert | 29 | 6,379,665 |
| security_note | 24 | 5,600,094 |
| correction | 4 | 3,485,237 |

### Agent mix

| agent_type | n |
|---|---|
| *(blank/unset)* | 30,889 |
| workflow-subagent | 13,832 |
| general-purpose | 8,752 |
| Explore | 1,601 |
| codebase-analyzer | 256 |
| claude | 184 |
| fork | 179 |
| Plan | 130 |
| web-search-researcher | 75 |

### Most expensive observations

| id | title | discovery_tokens | created_at |
|---|---|---|---|
| 81308 | Critical residual: SimulationTickState.year still crashes at… | 1,045,503 | 2026-07-18 |
| 51385 | Applied `-o addopts=""` fix to test:unit-ci and test:rest-ci | 1,045,260 | 2026-07-11 |
| 78322 | Completed Green Phase wiring of sustained_exploitation_magni… | 1,045,200 | 2026-07-18 |
| 80637 | Sentinel #44 inert-construct sentinel COMMITTED at c331d5ed… | 1,045,089 | 2026-07-18 |
| 113602 | Six verb_plate_view and issue_verb tests added to test_sessi… | 1,045,088 | 2026-07-22 |
| 54387 | Wave 4 workflow agents confirmed ACTIVE — transcripts still… | 1,044,929 | 2026-07-11 |
| 55470 | Two previously undocumented data:* mise tasks discovered: da… | 1,044,792 | 2026-07-12 |
| 71820 | Materials CLI test suite has 1 failure: dry-run rollback tes… | 1,044,695 | 2026-07-17 |
| 71821 | Materials CLI dry-run failure: MaterialsLoader commits inter… | 1,044,695 | 2026-07-17 |
| 44065 | Wave-3 worktree r34 provisioned — session preparing for park… | 1,044,639 | 2026-07-09 |

### ROI and its caveats

The compression ratio is the strongest measured evidence the memory system does real work: an average discovery costs ~194,228 tokens to produce and ~394 tokens to read back, a ~493× compression that survived a sanity check against raw SUM/MAX/AVG and is therefore not an artifact of a few skewed rows.

The savings estimate is explicitly modeled, not measured. Passive recall savings were computed as `424 sessions × (50 prior observations × 194,211 avg tokens) × 0.30 relevance factor ≈ 1,235,182,562 tokens`; explicit recall savings as `50 events × 10,000 tokens = 500,000`; total ≈ **1,235,682,562 tokens**. Against a `total_read_tokens_invested` of **21,825,572** (the aggregate cost of reading back every stored record), net ROI ≈ **56.6×**.

Three caveats should travel with those numbers. First, the 50-observations-per-session and 30%-relevance assumptions are declared inputs chosen to be conservative, not measured facts, and should be treated as adjustable parameters. Second, the explicit-recall count of 50 is a text-pattern proxy and a genuine lower bound — the schema has no `source_tool` column, so recalls that were not narrated in recall language are invisible. Third, and worth stating plainly rather than papering over: `SUM(relevance_count)` across all 55,898 babylon observations is **0**. Whatever mechanism is meant to increment that field on reuse has never fired for this project, so the "most-recalled memories" question simply cannot be answered from the current database.

## Timeline Statistics

The corpus runs from **Dec 5–6, 2025 to Jul 27, 2026** — roughly 234 calendar days, of which a much smaller number carry real activity. The economics query counts **55,898 observations** across **425 distinct memory sessions**; the chapter-level counts, summed, land in the same order of magnitude, and the job brief cites 52,801. The discrepancy is small relative to the totals and most plausibly reflects different filters (non-zero `discovery_tokens`, or project-scoping) rather than a substantive disagreement; the 55,898 figure is the one directly measured and is used here.

Activity is extraordinarily front-light and back-heavy. December 2025 through May 2026 produced ~19,750 observations and ~83M discovery tokens across six months. July 2026 produced 36,148 observations and 10.77B tokens in twenty-seven days. There are four real gaps in the record — Dec 14→25, Jan 6→18, Feb 9→23, and May 20→Jul 2 — plus missing months entirely in April and June, all of which read as genuine work pauses rather than capture failures.

The busiest days, by chapter-level counts, are Jul 20 (~50,000 observation IDs traversed, 500+ session headers, four complete programs from kickoff to merged-on-dev), Jul 19 (~3,100 observations, ~920 session headers, described by its analyst as the single busiest workday in the corpus), Jul 22–23 (~14,700 observation lines across 90+ sessions in one continuous overnight-plus-day marathon), Jul 15 (~6,600 observations, ~218 sessions, midnight to 11pm), and Jul 18 (~2,335 observations, ~520 sessions). Earlier, Dec 26, 2025 stands out as a single ~20-hour marathon of well over 1,400 observations, and Jul 7 as the densest day of the pre-remediation era with 400+ observations across two audit documents and a 14-agent review.

The type mix is dominated by discovery at 34,059 observations (61% of tokens), with change (9,658), feature (5,412), bugfix (3,176), refactor (1,646) and decision (1,890) following. Only 53 security observations exist across the entire corpus, and four corrections.

The longest sagas by wall-clock are the spec-067 QCEW migration (60+ hours of live migration across dozens of session resumes, #37524–37711), the recurring dashboard-layout bug that was fixed three times with three different root causes eleven days apart (Dec 14 and Dec 25), the mutmut mutation-testing fight (~4 hours across S951–S972 on Dec 26, and a caching regression escalated upstream as PR #471 in February), the Nix `PYTHONPATH` shadowing thread (all of Jul 21, recurring after its architectural fix), and the `event_type`/`type` field-name bug that was independently discovered and fixed **three separate times** across parallel branches (#54857–54996, #55495/#57725, #56278).

The engineering output around them: a Constitution at v2.18.0 with amendments A–AD, ADRs into the 150s, 33 engine systems in strict materialist-causality order, ~56 formula functions across 17 modules, 39 GameDefines category sub-models, 22 sentinel families, and a test suite that grew from 20 tests on Dec 5, 2025 to 9,786 by mid-July 2026.

## Lessons and Meta-Observations

A developer arriving at this history cold would take away five things.

**Green tests are not evidence.** The single most repeated failure mode in Babylon is not a broken test — it is a passing test over dead code. `imperial_rent` computed and never persisted (#56524). The endogenous interest rate green and structurally zero (#89885). The entire RAG pipeline implemented and silently returning `[]` (#105281). Financial calculators fully built with zero engine imports (#76973, #76989). The whole annual pipeline gated dead by a `melt_calculator` that was `None` in the regression harness (#79778). The eventual countermeasures — inert-construct sentinels, "correct-but-inert" review lenses, the gate-coverage-truth dynamic probe, ADR109's Wiring Doctrine requiring a sentinel row per wiring motion — are the project's most transferable invention, and they exist because the failure recurred often enough to be recognized as a *class* rather than a series of accidents.

**Debug at the level of the theory, not the symptom.** Every one of the project's most satisfying fixes was a modeling correction: the missing labor aristocracy behind the tick-2 stall (#4420), the wrong `SocialRole` behind statewide extinction (#39851), the reproductive-labor spectrum behind the 16-tick death threshold (#13600), the Emmanuel-Amin reframing of imperial rent mid-implementation (#21612–21621), the widened rate-of-profit band that was wrong in the *test* (#37659). The corresponding discipline is refusing to patch numerically when the model is what's incomplete — and writing the tension down when you cannot resolve it, as the Calibration Epistemology section did (#26405–26412).

**Speed and archaeology are the same budget.** The project moved extremely fast — forty Speckit features in three months, four full programs merged in a single day on Jul 20 — and paid for it in weeks of forensic recovery. `a5f73139` alone cost 363 test failures and six ADRs. Program 09's four parallel lanes produced a claimed 13/13 completion that shipped a game crashing at tick 0. CI sat silently disabled at the repo level from May 12 until Jul 10 (#49224). The lesson is not "go slower"; it is that a project running at this cadence must fund adversarial verification as a first-class activity, which Babylon eventually did — the Jul 5–7 audits, the 14-agent holistic review, the routine two-pass implement-then-review-subagent loop, and the Jul 21 practice of adversarially critiquing a *design* before implementing it and finding three blockers (#119225–119246).

**Make the gates real, and let them stop you.** The most impressive single moment in eight months is not a feature. It is Task 7 on Jul 20, where an agent produced genuine byte drift and, instead of forcing the merge, root-caused the ordering mechanism and rescoped its own deliverable (#93851, #93911). That behavior is only possible because the gates were mechanized: byte-identical `qa:regression` across six scenarios, the `Baselines: blessed(<slug>)` ceremony trailer enforced by pre-commit, pre-push range-diff and CI (#98254), import-linter contracts, the vocabulary sentinel that caught fabricated attributes from an 18-branch merge (#103613). Conventions that live only in documentation rot; the same day the ceremony gate went live, the team discovered that a nightly vocabulary check had been passing not because it was clean but because `rg` was missing from the runner and its absence was non-fatal (#99364, #99374). A silently-degraded gate is worse than no gate.

**Governance is engineering.** Babylon's Constitution, its ADR series, its amendment process and its ceremonies are not ornament — they are the mechanism by which a solo Director steered an agent workforce that wrote most of the code. The theoretical line stayed under human authority; the engineering autonomy was licensed by gate outcomes. That arrangement was informal for months, tested repeatedly (the Jul 14 audit loop, the Jul 18 pytest fan-out rule rescinded by explicit ruling after worktree isolation was verified, #80863), and finally written down on the last day in the record as Amendment AD and ADR151 (#123212, #123232). It is the closing argument of the whole history: as generation gets cheap, the durable assets are the contracts — the golden baselines, the byte-identity gates, the sentinels, the written rulings — because those are what let anyone, human or agent, tell the difference between a system that works and a system that merely passes.
